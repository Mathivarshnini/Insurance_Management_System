package dao;

import entity.Policy; // Import Policy class
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import util.DBConnUtil;

public class InsuranceServiceImpl implements IPolicyService {
    private Connection conn;

    public InsuranceServiceImpl() {
        this.conn = DBConnUtil.getConnection();
    }

    @Override
    public boolean createPolicy(Policy policy) {
    try {
        // Check if the clientId exists in the client table
        PreparedStatement checkClientStmt = conn.prepareStatement("SELECT COUNT(*) FROM client WHERE clientId = ?");
        checkClientStmt.setInt(1, policy.getClientId());
        ResultSet rs = checkClientStmt.executeQuery();
        if (rs.next() && rs.getInt(1) == 0) {
            System.out.println("Client ID does not exist in the client table.");
            return false;
        }

        // Proceed with policy insertion
        String query = "INSERT INTO policies (policyId, policyName, policyType, coverageAmount, premium, clientId) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, policy.getPolicyId());
        stmt.setString(2, policy.getPolicyName());
        stmt.setString(3, policy.getPolicyType());
        stmt.setDouble(4, policy.getCoverageAmount());
        stmt.setDouble(5, policy.getPremium());
        stmt.setInt(6, policy.getClientId());
        int rowsAffected = stmt.executeUpdate();
        return rowsAffected > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}


    @Override
    public Policy getPolicy(int policyId) {
        Policy policy = null;
        try {
            // Prepare the SQL query
            String query = "SELECT * FROM policies WHERE policyId = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, policyId);
    
            // Execute the query and process the result set
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                // Create a Policy object with the data from the result set
                policy = new Policy();
                policy.setPolicyId(rs.getInt("policyId"));
                policy.setPolicyName(rs.getString("policyName"));
                policy.setPolicyType(rs.getString("policyType"));
                policy.setCoverageAmount(rs.getDouble("coverageAmount"));
                policy.setPremium(rs.getDouble("premium"));
                policy.setClientId(rs.getInt("clientId"));
            }
    
            // Close the result set and statement
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return policy;
    }

    @Override
    public Collection<Policy> getAllPolicies() {
        Collection<Policy> policies = new ArrayList<>();
        try {
            // Prepare the SQL query to select all policies
            String query = "SELECT * FROM policies";
            PreparedStatement stmt = conn.prepareStatement(query);

            // Execute the query and process the result set
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                // Create a Policy object with the data from the result set
                Policy policy = new Policy();
                policy.setPolicyId(rs.getInt("policyId"));
                policy.setPolicyName(rs.getString("policyName"));
                policy.setPolicyType(rs.getString("policyType"));
                policy.setCoverageAmount(rs.getDouble("coverageAmount"));
                policy.setPremium(rs.getDouble("premium"));
                policy.setClientId(rs.getInt("clientId"));

                // Add the policy to the collection
                policies.add(policy);
            }

            // Close the result set and statement
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return policies;
    }


    @Override
public boolean updatePolicy(Policy policy) {
    try {
        // Prepare the SQL query to update a policy
        String query = "UPDATE policies SET policyName = ?, policyType = ?, coverageAmount = ?, premium = ?, clientId = ? WHERE policyId = ?";
        PreparedStatement stmt = conn.prepareStatement(query);

        // Set the parameters for the query
        stmt.setString(1, policy.getPolicyName());
        stmt.setString(2, policy.getPolicyType());
        stmt.setDouble(3, policy.getCoverageAmount());
        stmt.setDouble(4, policy.getPremium());
        stmt.setInt(5, policy.getClientId());
        stmt.setInt(6, policy.getPolicyId());

        // Execute the update query
        int rowsAffected = stmt.executeUpdate();

        // Close the statement
        stmt.close();

        // Return true if at least one row was updated
        return rowsAffected > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}


@Override
public boolean deletePolicy(int policyId) {
    try {
        // Prepare the SQL query to delete a policy
        String query = "DELETE FROM policies WHERE policyId = ?";
        PreparedStatement stmt = conn.prepareStatement(query);

        // Set the policyId parameter for the query
        stmt.setInt(1, policyId);

        // Execute the delete query
        int rowsAffected = stmt.executeUpdate();

        // Close the statement
        stmt.close();

        // Return true if at least one row was deleted
        return rowsAffected > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

}
